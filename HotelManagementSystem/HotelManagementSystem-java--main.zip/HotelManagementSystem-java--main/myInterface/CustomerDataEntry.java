package myinterface;

public interface CustomerDataEntry {
  void getCustomerData();
}
